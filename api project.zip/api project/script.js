let animals = ["cheetah", "lion", "cat", "dog", "bear"];
let favAnimal = document.querySelector("#animalName");

async function getAnimal() {
  const url = "https://random-animal-api.vercel.app/api/random-animal";
  //"https://api.api-ninjas.com/v1/animals?name=" + animals[Math.floor(Math.random() * 5)];
  const response = await fetch(url);

  const animaldata = await response.json();

  console.log(animaldata);
  favAnimal.innerHTML = "Their favorite Animal: " + animaldata.city;
}
getAnimal();

let pokeName = document.querySelector("#name");

async function getPokemonData() {
  const url =
    "https://pokeapi.co/api/v2/pokemon/" + Math.ceil(Math.random() * 150);

  const response = await fetch(url);

  const data = await response.json();
  console.log(data);

  pokeName.innerHTML = `Pokemon name: ${data.name}`;

  let image = document.querySelector("#pokemon");
  image.src = data.sprites.front_default;
}

getPokemonData();
